from prml.bayesnet.discrete import discrete, DiscreteVariable


__all__ = [
    "DiscreteVariable",
    "discrete"
]
