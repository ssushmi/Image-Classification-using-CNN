class Classifier(object):
    """
    Base class for classifiers
    """
    pass
