class Regression(object):
    """
    Base class for regressors
    """
    pass
